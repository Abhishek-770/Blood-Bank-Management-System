package com.example.blood_bank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

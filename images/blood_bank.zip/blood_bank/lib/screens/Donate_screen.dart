import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:blood_bank/components/rounded_button.dart';
import 'dart:developer';
import 'home_screen.dart';
class DonateScreen extends StatefulWidget {

  static String donateId='Donate_screen';
  @override
  _DonateScreenState createState() => _DonateScreenState();
}

class _DonateScreenState extends State<DonateScreen> {
  final TextEditingController locationController=TextEditingController();

  DateTime selectedDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2021),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }
  void register(){
    String location=locationController.text.trim();
    String date =selectedDate.toString();
  if(date!=null && location!=null){
    Map<String,dynamic>donor={
      "date":date,
      "donor_location":location,

    };
    FirebaseFirestore.instance.collection("donor").add(donor);
    log("user created");
    Navigator.pushNamed(context, HomeScreen.homeId);
  }
  else{
    log("fill all the details");
  }

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
        TextField(
        controller:locationController,
          textAlign:TextAlign.center,

        keyboardType: TextInputType.emailAddress,
        decoration:  const InputDecoration(
        hintText: 'Select District For Blood Donation',
          hintStyle: TextStyle(
            color: Colors.black54,
          ),
        ),

        // onChanged: (value){
        //   controller.text=value;
        //   log(value);
        // },

      ),
          SizedBox(height: 20.0,),
          Text("${selectedDate.toLocal()}".split(' ')[0]),
          SizedBox(height: 20.0,),
          ElevatedButton(
            onPressed: () => _selectDate(context),
            child: Text('Select date'),
          ),
          RoundedButton(title: "Register For Donation",
              colour: Colors.blueAccent, onPressed : () {
                register();

              }),
        ],

      ),
    ),

    );
  }
}
